<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author HokkaidoPerson <dosankomali@yahoo.co.jp>
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['connectfail']           = 'データベースへの接続に失敗しました。';
$lang['userexists']            = '恐れ入りますが、このログイン名のユーザーが既に存在しています。';
$lang['writefail']             = 'ユーザーデータを変更できません。Wiki の管理者に連絡してください。';
