<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Frederico Gonçalves Guimarães <frederico@teia.bio.br>
 */
$lang['connectfail']           = 'Não foi possível conectar ao banco de dados.';
$lang['userexists']            = 'Desculpe, mas já existe esse nome de usuário.';
$lang['writefail']             = 'Não foi possível modificar os dados do usuário. Por favor, informe ao administrador do Wiki.';
