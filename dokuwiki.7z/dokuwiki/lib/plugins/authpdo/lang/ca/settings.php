<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Marc Zulet <marczulet@gmail.com>
 * @author Adolfo Jayme Barrientos <fito@libreoffice.org>
 */
$lang['debug']                 = 'Mostra missatges d\'error detallats. S\'hauria de desactivar després de la configuració.';
$lang['dsn']                   = 'El DNS per a connectar a la base de dades.';
