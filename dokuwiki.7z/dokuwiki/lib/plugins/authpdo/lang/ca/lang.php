<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Adolfo Jayme Barrientos <fito@libreoffice.org>
 */
$lang['connectfail']           = 'Ha fallat la connexió a la base de dades.';
$lang['userexists']            = 'Ja existeix un usuari amb aquest nom.';
$lang['writefail']             = 'No es poden modificar les dades de l’usuari. Informeu d’això a l’administrador del wiki';
