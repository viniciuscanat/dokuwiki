<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['connectfail']           = 'پەیوەندی کردن بە بنکەی زانیاری سەرکەوتوو نەبوو.';
$lang['userexists']            = 'ببوورە، بەکارهێنەرێک بەم زانیارییە بوونی هەیە.	';
$lang['writefail']             = 'ناتوانێت دەستکاری داتای بەکارهێنەر بکات. تکایە ویکی-بەڕێوەبەرەکە بکەرەوە';
