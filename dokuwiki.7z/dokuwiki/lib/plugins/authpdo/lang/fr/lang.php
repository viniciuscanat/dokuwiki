<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Pietroni <pietroni@informatique.univ-paris-diderot.fr>
 */
$lang['connectfail']           = 'Impossible de se connecter à la base de données.';
$lang['userexists']            = 'Désolé, un utilisateur avec cet identifiant existe déjà.';
$lang['writefail']             = 'Impossible de modifier les données utilisateur. Veuillez en informer l\'administrateur du Wiki.';
