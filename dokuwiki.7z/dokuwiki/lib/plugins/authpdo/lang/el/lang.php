<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aikaterini Katapodi <extragold1234@hotmail.com>
 */
$lang['connectfail']           = 'Δεν μπόρεσε να κάνει σύνδεση με την βάση δεδομένων';
$lang['userexists']            = 'Συγγνώμη υπάρχει ήδη χρήστης με αυτά τα στοιχεία';
$lang['writefail']             = 'Δεν μπορέσαμε τα τροποποιήσουμε τα στοιχεία χρήστη. Παρακαλώ ενημερώστε το Wiki-Admin';
