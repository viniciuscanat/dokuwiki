<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <mail@jacobpalm.dk>
 */
$lang['connectfail']           = 'Kunne ikke forbinde til database.';
$lang['userexists']            = 'Beklager, en bruger med dette loginnavn findes allerede.';
$lang['writefail']             = 'Kunne ikke ændre brugerdata. Informer venligst wikiens administrator.';
