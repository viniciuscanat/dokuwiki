<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Patrik K Lundberg <patrik.kotiranta.lundberg@gmail.com>
 */
$lang['connectfail']           = 'Misslyckades med att ansluta databas.';
$lang['userexists']            = 'PHP mail() saknas eller är inaktiverad. Följande mejl skickades inte:';
$lang['writefail']             = 'Wiki Markup';
