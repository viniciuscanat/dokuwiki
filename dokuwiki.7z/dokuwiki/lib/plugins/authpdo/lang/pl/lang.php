<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Przemek <p_kudriawcew@o2.pl>
 */
$lang['connectfail']           = 'Błąd łącznie się z bazą danych';
$lang['userexists']            = 'Przepraszamy, użytkownik o tym loginie już istnieje';
$lang['writefail']             = 'Nie można zmodyfikować danych użytkownika. Proszę skontaktować się z Administratorem';
