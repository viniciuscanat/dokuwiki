<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Marton Sebok <sebokmarton@gmail.com>
 */
$lang['connectfail']           = 'Az adatbázishoz való csatlakozás sikertelen.';
$lang['userexists']            = 'Sajnos már létezik ilyen azonosítójú felhasználó.';
$lang['writefail']             = 'A felhasználói adatok módosítása sikertelen. Kérlek, fordulj a wiki rendszergazdájához!';
