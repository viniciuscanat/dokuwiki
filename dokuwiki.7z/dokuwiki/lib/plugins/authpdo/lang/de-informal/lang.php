<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin <martin@andev.de>
 */
$lang['connectfail']           = 'Verbindung zur Datenbank fehlgeschlagen.';
$lang['userexists']            = 'Der Benutzername existiert leider schon.';
$lang['writefail']             = 'Die Benutzerdaten konnten nicht geändert werden. Bitte wenden Sie sich an den Wiki-Admin.';
