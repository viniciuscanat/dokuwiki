<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['connectfail']           = 'Nepodarilo sa pripojiť k databáze.';
$lang['userexists']            = 'Ľutujem, ale používateľ s týmto prihlasovacím menom už existuje.';
$lang['writefail']             = 'Nie je možné zmeniť údaje používateľa, informujte prosím administrátora Wiki.';
