<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Dmytro Marchenko <dmytro.marchenko1989@gmail.com>
 */
$lang['connectfail']           = 'Не вдалося підключитися до бази даних.';
$lang['userexists']            = 'На жаль, користувач із цим логіном вже існує.';
$lang['writefail']             = 'Неможливо змінити дані користувача. Будь-ласка, повідомте про це Wiki-Адміністратора';
