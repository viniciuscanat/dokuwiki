<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author no credits taken <someone@cambodia.kh>
 */
$lang['where']                 = 'ទំព័រ/ដ្ឋាននាម';
