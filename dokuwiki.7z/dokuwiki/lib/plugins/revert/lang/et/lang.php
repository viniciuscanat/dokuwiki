<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Janar Leas <janar.leas@eesti.ee>
 */
$lang['note1']                 = 'Teadmiseks: See otsing arvestab suurtähti';
$lang['note2']                 = 'Teadmiseks: Lehekülg ennistatakse viimasele järgule, milles ei sisaldu antud rämpsu sõne <i>%s</i>.';
