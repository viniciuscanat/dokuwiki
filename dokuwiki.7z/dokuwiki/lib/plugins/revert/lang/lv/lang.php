<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['menu']                  = 'Piemēsloto lapu atjaunotājs';
$lang['filter']                = 'Meklēt piemēslotās lapas';
$lang['revert']                = 'Atjaunot norādītās lapas ';
$lang['reverted']              = '%s atjaunots uz %s stāvokli';
$lang['removed']               = '%s dzēsts';
$lang['revstart']              = 'Atjaunošana uzsākta. Tas var aizņemt ilgāku laiku. Ja darbība pārtrūkst noilguma dēļ, atjaunošana jāveic pa mazākām porcijām.';
$lang['revstop']               = 'Atjaunošana veiksmīgi  pabeigta. ';
$lang['note1']                 = 'Ievēro: Meklēšana atšķir lielos un mazos burtus.';
$lang['note2']                 = 'Ievēro: Lapu atjaunos ar pēdējo versiju, kas nesatur uzdoto spama vārdu <i>%s</i>.';
