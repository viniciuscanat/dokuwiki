<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Dotan Kamber <kamberd@yahoo.com>
 * @author Moshe Kaplan <mokplan@gmail.com>
 * @author Yaron Yogev <yaronyogev@gmail.com>
 * @author Yaron Shahrabani <sh.yaron@gmail.com>
 */
$lang['name']                  = 'משוב פופולריות (יתכן זמן טעינה ארוך)';
$lang['submit']                = 'שלח מידע';
