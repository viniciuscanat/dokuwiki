<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Komgrit Niyomrath <n.komgrit@gmail.com>
 * @author Kittithat Arnontavilas <mrtomyum@gmail.com>
 * @author Thanasak Sompaisansin <jombthep@gmail.com>
 */
$lang['name']                  = 'ส่งข้อมูลความนิยมกลับ (อาจใช้เวลาในการโหลด)';
$lang['submit']                = 'ส่งข้อมูล';
