<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['userexists']            = 'Užívateľ s rovnakým menom je už zaregistrovaný.';
$lang['usernotexists']         = 'Ľutujem, daný používateľ neexistuje.';
$lang['writefail']             = 'Nie je možné zmeniť údaje používateľa, informujte prosím administrátora Wiki.';
$lang['protected']             = 'Údaje používateľa %s sú chránené a nemôžu by zmenené alebo vymazané.';
