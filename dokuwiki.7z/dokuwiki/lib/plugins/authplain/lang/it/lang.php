<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Torpedo <dgtorpedo@gmail.com>
 * @author Riccardo <riccardofila@gmail.com>
 */
$lang['userexists']            = 'Il nome utente inserito esiste già.';
$lang['usernotexists']         = 'Spiacente, quell\'utente non esiste.';
$lang['writefail']             = 'Impossibile modificare i dati utente. Per favore informa l\'Amministratore del Wiki';
$lang['protected']             = 'I dati relativi all\'utente %s sono protetti e non possono essere modificati o cancellati.';
