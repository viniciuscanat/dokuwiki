<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['userexists']            = 'ببوورە، بەکارهێنەرێک کە ئەم چوونەژوورەوەی هەیە.';
$lang['usernotexists']         = 'ببوورە، ئەم بەکارهێنەرە بوونی نییە.';
$lang['writefail']             = 'ناتوانێت دەستکاری داتای بەکارهێنەر بکات. تکایە ویکی-بەڕێوەبەرەکە بکەرەوە';
$lang['protected']             = 'داتای بەکارهێنەر %s پارێزراوە و ناتوانرێت دەستکاری بکرێت یان بسڕدرێتەوە.';
