<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Max <maxrb146@gmail.com>
 */
$lang['userexists']            = 'Użytkownik o tej nazwie już istnieje.';
$lang['usernotexists']         = 'Przepraszamy, użytkownik nie istnieje';
$lang['writefail']             = 'Nie można modyfikować danych użytkownika. Proszę skontaktować się z administratorem ';
$lang['protected']             = 'Dane użytkownika %s są chronione, nie mogą być modyfikowane oraz usuwane';
