<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Katerina Katapodi <extragold1234@hotmail.com>
 */
$lang['userexists']            = 'Αυτός ο λογαριασμός υπάρχει ήδη.';
$lang['usernotexists']         = 'Λυπάμαι, αυτός ο χρήστης δεν υπάρχει.';
$lang['writefail']             = 'Δεν μπόρεσε να τροποποιήσει τα δεδομένα χρήστη. Παρακαλώ ενημερώστε το Wiki-Admin';
$lang['protected']             = ' Τα δεδομένα  χρήστη %s είναι εμπιστευτικά και δεν μπορούν να τροποποιηθούν ή απαλειφθούν.';
