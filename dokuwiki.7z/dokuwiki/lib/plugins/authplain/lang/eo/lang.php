<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Kristjan SCHMIDT <kristjan.schmidt@googlemail.com>
 */
$lang['userexists']            = 'Pardonu, ĉi tiu uzanto-nomo jam ekzistas.';
$lang['usernotexists']         = 'Pardonu, tiu uzanto ne ekzistas.';
