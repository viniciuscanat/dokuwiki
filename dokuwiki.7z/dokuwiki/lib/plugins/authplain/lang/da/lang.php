<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <mail@jacobpalm.dk>
 * @author Kenneth Schack Banner <kescba@gmail.com>
 */
$lang['userexists']            = 'Dette brugernavn er allerede i brug.';
$lang['usernotexists']         = 'Beklager, brugeren eksisterer ikke.';
$lang['writefail']             = 'Ude af stand til at redigere bruger data. Kontakt venligst Wiki-Administratoren';
$lang['protected']             = 'Data for brugeren %s er beskyttet, og kan ikke ændres eller slettes.';
