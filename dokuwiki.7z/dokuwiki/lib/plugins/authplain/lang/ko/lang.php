<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['userexists']            = '죄송하지만 같은 이름을 사용하는 사용자가 있습니다.';
$lang['usernotexists']         = '죄송하지만 해당 사용자가 존재하지 않습니다.';
$lang['writefail']             = '사용자 데이터를 수정할 수 없습니다. 위키 관리자에게 문의하시기 바랍니다';
$lang['protected']             = '%s 사용자의 데이터는 잠겨 있어 수정하거나 삭제할 수 없습니다.';
