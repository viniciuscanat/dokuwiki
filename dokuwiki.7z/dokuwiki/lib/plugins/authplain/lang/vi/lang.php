<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thien Hau <thienhau.9a14@gmail.com>
 */
$lang['userexists']            = 'Xin lỗi, thành viên có thông tin đăng nhập này đã tồn tại.';
$lang['usernotexists']         = 'Xin lỗi, thành viên đó không tồn tại.';
$lang['writefail']             = 'Không thể sửa đổi dữ liệu thành viên. Vui lòng thông báo cho Quản trị viên Wiki';
$lang['protected']             = 'Dữ liệu cho thành viên %s được bảo vệ và không thể sửa đổi hoặc xóa.';
