<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author En Mathis <heartattack@free.fr>
 */
$lang['__link__']              = 'La color generala dels ligams';
$lang['__existing__']          = 'La color pels ligams cap a paginas qu\'existisson';
$lang['__missing__']           = 'La color pels ligams cap a paginas qu\'existisson pas';
