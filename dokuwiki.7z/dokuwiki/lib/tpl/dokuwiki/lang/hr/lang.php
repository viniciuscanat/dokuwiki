<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['__background_site__']   = 'Boja pozadine ispod okvira sa sadržajem';
$lang['__link__']              = 'Boja opće poveznice';
$lang['__existing__']          = 'Boja poveznice na postojeće stranice';
$lang['__missing__']           = 'Boja poveznice na nepostojeće stranice';
$lang['__site_width__']        = 'Širina pune stranice (može biti bilo koja jedinica: %, px, em, ...)';
$lang['__sidebar_width__']     = 'Širina bočne stranice, ako postoji (može biti bilo koja jedinica: %, px, em, ...)';
$lang['__tablet_width__']      = 'Ispod ove širine, prebaci mod prikaza za tablete';
$lang['__phone_width__']       = 'Ispod ove širine, prebaci mod prikaza za mobilni telefon';
$lang['__theme_color__']       = 'Boja teme web aplikacija';
