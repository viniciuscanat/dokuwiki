<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Marton Sebok <sebokmarton@gmail.com>
 */
$lang['__background_site__']   = 'Lap színe (a tartalom mögött)';
$lang['__link__']              = 'Hivatkozás általános színe';
$lang['__existing__']          = 'Hivatkozása színe létező lapoknál';
$lang['__missing__']           = 'Hivatkozása színe nem létező lapoknál';
$lang['__site_width__']        = 'Az oldal teljes szélessége (tetszőleges mértékegységgel: %, px, em, ...)';
$lang['__sidebar_width__']     = 'Az oldalsáv szélessége (tetszőleges mértékegységgel: %, px, em, ...)';
$lang['__tablet_width__']      = 'Váltás tablet-módra ezen szélesség alatt';
$lang['__phone_width__']       = 'Váltás mobiltelefon-módra ezen szélesség alatt';
